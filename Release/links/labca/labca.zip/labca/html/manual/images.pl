# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/>;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$&gt;$">|; 

$key = q/>=10;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$&gt;=10$">|; 

$key = q/=10+INVALID_ALARM;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="207" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$=10 + INVALID\_ALARM$">|; 

$key = q/<;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$&lt;$">|; 

$key = q/=10+INVALID_ALARM+1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="234" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$= 10 + INVALID\_ALARM + 1$">|; 

$key = q/<1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$&lt;1$">|; 

1;

